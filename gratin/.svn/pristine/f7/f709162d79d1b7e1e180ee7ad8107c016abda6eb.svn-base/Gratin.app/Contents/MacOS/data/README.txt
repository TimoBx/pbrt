Images and 3D models included are all in the public domain for non-commercial usage! 

The spot (objs/spot.obj, imgs/spot.png) was created by Keenan Crane. 
See http://www.cs.columbia.edu/~keenan/Projects/ModelRepository/

The dog picture (imgs/dog.jpg) was taken by Viktor Hanacek:
https://picjumbo.com/tag/animals-2/page/2/

The mountain (imgs/mountain.jpg) was taken by Zivotnacestach.cz: 
https://picjumbo.com/mount-cook-national-park/

The flower (imgs/flower.jpg) comes from: 
http://www.copyrightfreephotos.com/photo/125791881 (unkown author)

The environment map (imgs/envmap.jpg) was created by Mark Curtis:
http://community.thefoundry.co.uk/discussion/topic.aspx?f=4&t=80897

The exr images (imgs/crete-seashore.exr, imgs/horseshoe-lake.exr)
come from EMPA Media Tech.: http://www.empamedia.ethz.ch/hdrdatabase
